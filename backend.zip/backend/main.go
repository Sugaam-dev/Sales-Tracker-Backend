package main

import (
	"log/slog"
	"os"

	"github.com/gin-gonic/gin"

	"crm-auth-service/conf"
	"crm-auth-service/controllers"
	"crm-auth-service/helpers"
	"crm-auth-service/middleware"
	"crm-auth-service/repository"
	"crm-auth-service/routes"
	"crm-auth-service/services"
)

func main() {
	cfg, err := conf.LoadConfig()
	if err != nil {
		// Logger isn't built yet — config failure is always fatal, so a
		// plain stderr write is correct here, not a slog call.
		os.Stderr.WriteString("config error: " + err.Error() + "\n")
		os.Exit(1)
	}

	log := newLogger(cfg.Server.Env)

	db, err := conf.ConnectDB(cfg.DB, log)
	if err != nil {
		log.Error("failed to connect to database", "error", err)
		os.Exit(1)
	}
	sqlDB, err := db.DB()
	if err != nil {
		log.Error("failed to get underlying sql.DB", "error", err)
		os.Exit(1)
	}
	defer sqlDB.Close()

	// --- Dependency wiring ---------------------------------------------
	// Repositories (data access)
	userRepo := repository.NewUserRepository(db)
	sessionRepo := repository.NewSessionRepository(db)
	otpRepo := repository.NewUserEmailOTPRepository(db)

	// Cross-cutting helpers
	jwtManager := helpers.NewJWTManager(cfg.JWT)
	emailService := helpers.NewConsoleEmailService(log)
	smsService := helpers.NewConsoleSMSService(log)
	rateLimiter := middleware.NewRateLimiter(cfg.Rate.MaxAttempts, cfg.Rate.Window)

	// Business logic
	authService := services.NewAuthService(
		userRepo, sessionRepo, otpRepo,
		jwtManager, emailService, smsService,
		rateLimiter, log,
	)

	// HTTP layer
	authController := controllers.NewAuthController(authService, log)

	
	if cfg.Server.Env == "production" {
		gin.SetMode(gin.ReleaseMode)
	}

	router := gin.New()

	// Set trusted proxies BEFORE starting the server
	router.SetTrustedProxies(nil)

	router.Use(gin.Recovery())


	// Register application routes
	routes.RegisterRoutes(router, authController)

	log.Info("starting server", "port", cfg.Server.Port, "env", cfg.Server.Env)

	if err := router.Run(":" + cfg.Server.Port); err != nil {
		log.Error("server stopped", "error", err)
		os.Exit(1)
	}
}

// newLogger builds the structured logger: JSON in production, text in
// development.
func newLogger(env string) *slog.Logger {
	opts := &slog.HandlerOptions{Level: slog.LevelInfo}
	if env == "development" {
		opts.Level = slog.LevelDebug 
	}
	var handler slog.Handler
	if env == "production" {
		handler = slog.NewJSONHandler(os.Stdout, opts)
	} else {
		handler = slog.NewTextHandler(os.Stdout, opts)
	}
	return slog.New(handler)
}