package helpers

import (
	"errors"
	"net/http"
	"time"
)

// ErrNotFound is returned by repositories instead of leaking
// gorm.ErrRecordNotFound (or any other driver-specific error) up to the
// service layer.
var ErrNotFound = errors.New("record not found")

// AppError is a deliberate, user-facing error: its Message is always
// safe to return to the client as-is. Any error that is NOT an
// *AppError reaching a controller is unexpected — logged in full, and
// masked behind a generic 500 (see RespondError in response_helper.go).
type AppError struct {
	Status     int
	Message    string
	RetryAfter time.Duration // >0 only for rate-limit errors
}

func (e *AppError) Error() string { return e.Message }

// ErrInvalidCredentials — 401. Identical whether the user wasn't found
// or the password was wrong, per the doc's anti-enumeration rule.
func ErrInvalidCredentials() *AppError {
	return &AppError{Status: http.StatusUnauthorized, Message: "Invalid credentials"}
}

// ErrTokenInvalid — 401. Expired/malformed/revoked refresh, temp, or
// mfa_pending tokens.
func ErrTokenInvalid(message string) *AppError {
	return &AppError{Status: http.StatusUnauthorized, Message: message}
}

// ErrRateLimited — 429, with the Retry-After duration the response
// layer sets as a header.
func ErrRateLimited(retryAfter time.Duration) *AppError {
	return &AppError{
		Status:     http.StatusTooManyRequests,
		Message:    "Too many login attempts. Please try again later.",
		RetryAfter: retryAfter,
	}
}

// ErrBadRequest — 400, for request validation failures.
func ErrBadRequest(message string) *AppError {
	return &AppError{Status: http.StatusBadRequest, Message: message}
}

// ErrInternal — 500. Message is always generic; the real error is
// logged by the caller, never returned to the client.
func ErrInternal() *AppError {
	return &AppError{Status: http.StatusInternalServerError, Message: "Something went wrong. Please try again."}
}