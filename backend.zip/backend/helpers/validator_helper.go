package helpers

import (
	"strings"
	"unicode"
)

// IsEmailIdentifier implements the doc's exact detection rule for
// POST /auth/login: "if it contains '@' it is an email; otherwise treat
// it as mobile."
func IsEmailIdentifier(identifier string) bool {
	return strings.Contains(identifier, "@")
}

// ValidatePasswordStrength enforces the doc's rule: min 8 characters, at
// least 1 uppercase letter, at least 1 number. Login (Module A) doesn't
// call this — it only verifies an existing hash — but set-password and
// reset-password (other modules) both need this exact rule.
func ValidatePasswordStrength(pwd string) error {
	var hasUpper, hasDigit bool
	for _, r := range pwd {
		switch {
		case unicode.IsUpper(r):
			hasUpper = true
		case unicode.IsDigit(r):
			hasDigit = true
		}
	}

	var problems []string
	if len(pwd) < 8 {
		problems = append(problems, "at least 8 characters")
	}
	if !hasUpper {
		problems = append(problems, "at least 1 uppercase letter")
	}
	if !hasDigit {
		problems = append(problems, "at least 1 number")
	}
	if len(problems) > 0 {
		return ErrBadRequest("Password must contain " + strings.Join(problems, ", "))
	}
	return nil
}