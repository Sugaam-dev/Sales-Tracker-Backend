package helpers

import (
	"errors"
	"log/slog"
	"strconv"

	"github.com/gin-gonic/gin"
)

// SuccessResponse writes data as the top-level JSON body — matching the
// auth documentation's example responses exactly (e.g. { access_token,
// refresh_token, user }), with no wrapping envelope.
func SuccessResponse(c *gin.Context, status int, data any) {
	c.JSON(status, data)
}

type errorBody struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
}

// ErrorResponse writes a generic error response.
func ErrorResponse(c *gin.Context, status int, message string) {
	c.JSON(status, errorBody{Success: false, Message: message})
}

// RespondError translates a service-layer error into an HTTP response.
// An *AppError's Message is always safe to show the client as-is.
// Anything else is unexpected — logged in full, with only a generic 500
// shown to the client (never raw DB errors, file paths, etc.).
func RespondError(c *gin.Context, err error, log *slog.Logger) {
	var appErr *AppError
	if errors.As(err, &appErr) {
		if appErr.RetryAfter > 0 {
			c.Header("Retry-After", strconv.Itoa(int(appErr.RetryAfter.Seconds())))
		}
		ErrorResponse(c, appErr.Status, appErr.Message)
		return
	}

	log.Error("unhandled error", "error", err)
	internal := ErrInternal()
	ErrorResponse(c, internal.Status, internal.Message)
}