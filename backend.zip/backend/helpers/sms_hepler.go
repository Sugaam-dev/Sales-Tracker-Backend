package helpers

import "log/slog"

// SMSService sends the MFA OTP by SMS, for users with mfa_method =
// "sms". Same interface-stability rationale as EmailService: swap the
// implementation, not the call sites, when a real SMS provider is
// integrated.
type SMSService interface {
	SendOTP(toMobile, otp string) error
}

// consoleSMSService is the current implementation: log the OTP to the
// console instead of sending a real SMS.
type consoleSMSService struct {
	log *slog.Logger
}

func NewConsoleSMSService(log *slog.Logger) SMSService {
	return &consoleSMSService{log: log}
}

func (s *consoleSMSService) SendOTP(toMobile, otp string) error {
	s.log.Info("MFA OTP (console dev mode)", "to", toMobile, "otp", otp)
	return nil
}