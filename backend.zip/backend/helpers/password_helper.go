package helpers

import "golang.org/x/crypto/bcrypt"

// bcryptCost 12 is mandated by the auth documentation — "do not change this."
const bcryptCost = 12

// HashPassword bcrypt-hashes a plaintext password.
func HashPassword(plain string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(plain), bcryptCost)
	if err != nil {
		return "", err
	}
	return string(bytes), nil
}

// ComparePassword reports whether plain matches the stored bcrypt hash.
// bcrypt's comparison is already constant-time, so this alone is safe
// against timing attacks — callers must still return the same generic
// error on both "user not found" and "wrong password" (see
// services.AuthService.Login) to avoid a user-enumeration side channel.
func ComparePassword(plain, hash string) bool {
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(plain)) == nil
}