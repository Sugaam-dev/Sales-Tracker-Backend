package helpers

import "log/slog"

// EmailService sends the MFA OTP by email, for users with mfa_method =
// "email". Swap the implementation, not the call sites, when a real
// Email provider is integrated.
type EmailService interface {
	SendOTP(toEmail, otp string) error
}

// consoleEmailService is the current implementation: log the OTP to the
// console instead of sending a real Email.
type consoleEmailService struct {
	log *slog.Logger
}

func NewConsoleEmailService(log *slog.Logger) EmailService {
	return &consoleEmailService{log: log}
}

func (s *consoleEmailService) SendOTP(toEmail, otp string) error {
	s.log.Info("MFA OTP (console dev mode)", "to", toEmail, "otp", otp)
	return nil
}
