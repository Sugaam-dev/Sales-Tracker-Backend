# CRM Authentication Service

A production-ready Authentication Service built in Go using the Gin Framework.

This project is designed using Clean Architecture principles and is intended to be the authentication module of a CRM system.

---

# Features

## Module A (Implemented)

- User Login
- Refresh Token
- JWT Authentication
- First Login Flow
- MFA Trigger (OTP Generation)
- Login Rate Limiting
- PostgreSQL Integration
- Auto Database Creation
- Auto Migration
- Swagger API Documentation
- Structured Logging
- Clean Architecture

---

## Future Modules

The architecture is designed to support future authentication modules including:

- Password Reset
- Email Verification
- Mobile Verification
- MFA Verification
- Google Login
- Azure SSO
- User Registration
- User Onboarding
- Role Based Authorization

---

# Technology Stack

| Technology | Version |
|------------|---------|
| Go | 1.22+ |
| Gin | Latest |
| PostgreSQL | Latest |
| GORM | Latest |
| JWT | golang-jwt |
| UUID | google/uuid |
| bcrypt | x/crypto |
| Swagger | Swaggo |
| slog | Standard Library |

---

# Project Structure

```

crm-auth-service/
│
├── main.go
├── go.mod
├── README.md
├── .env.example
│
├── conf/
├── controllers/
├── helpers/
├── middleware/
├── models/
├── repository/
├── routes/
├── services/
├── docs/
└── scripts/

```

---

# Prerequisites

Install the following before running the project.

- Go 1.22 or newer
- PostgreSQL
- Git

---

# Clone Repository

```bash
git clone <repository-url>

cd crm-auth-service
```

---

# Install Dependencies

```bash
go mod tidy
```

---

# Environment Variables

Create a `.env` file from `.env.example`

Example

```env
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=postgres
DB_NAME=crm_auth

JWT_SECRET=your_secret_key

SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=example@gmail.com
SMTP_PASSWORD=password
```

---

# Database

The application automatically

- creates the database (if it does not exist)
- connects to PostgreSQL
- runs GORM AutoMigrate
- creates all required tables
- creates indexes
- creates constraints

No SQL scripts are required.

---

# Run Project

```bash
go run main.go
```

---

# Swagger

Generate Swagger

```bash
swag init
```

Open

```
http://localhost:8080/swagger/index.html
```

---

# API Endpoints

## Login

```
POST /auth/login
```

---

## Refresh

```
POST /auth/refresh
```

---

# Authentication Flow

```
Login

↓

Validate Request

↓

Rate Limit Check

↓

Find User

↓

Verify Password

↓

First Login

↓

Generate OTP (If MFA Enabled)

↓

Generate JWT

↓

Generate Refresh Token

↓

Store Refresh Token

↓

Return Response
```

---

# Running Tests

```bash
go test ./...
```

---

# Logging

Structured logging is implemented using

```
log/slog
```

---

# Security

The project follows the following security standards.

- bcrypt password hashing
- SHA-256 refresh token hashing
- Secure JWT
- UUID Primary Keys
- Generic Login Errors
- Secure Random OTP Generation
- Rate Limiting
- Clean Architecture

---

# Future Improvements

- Password Reset
- MFA Verification
- Google Login
- Azure Login
- Redis Rate Limiter
- Email Service
- SMS Service

---

# Author

CRM Authentication Service

Internship Project

Built using Go, Gin and PostgreSQL.