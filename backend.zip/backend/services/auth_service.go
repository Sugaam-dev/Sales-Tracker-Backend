// Package services holds business logic. AuthService owns the Login and
// Refresh flows end to end — controllers only parse requests and call
// these methods; repositories only run queries. Every branch below maps
// directly to a numbered step in the auth documentation.
package services

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"time"

	"crm-auth-service/helpers"
	"crm-auth-service/middleware"
	"crm-auth-service/models"
	"crm-auth-service/repository"
)

const (
	refreshTokenTTL = 7 * 24 * time.Hour
	mfaOTPTTL       = 5 * time.Minute
)

type AuthService struct {
	userRepo    repository.UserRepository
	sessionRepo repository.SessionRepository
	otpRepo     repository.UserEmailOTPRepository
	jwtManager  *helpers.JWTManager
	emailSvc    helpers.EmailService
	smsSvc      helpers.SMSService
	rateLimiter *middleware.RateLimiter
	log         *slog.Logger
}

func NewAuthService(
	userRepo repository.UserRepository,
	sessionRepo repository.SessionRepository,
	otpRepo repository.UserEmailOTPRepository,
	jwtManager *helpers.JWTManager,
	emailSvc helpers.EmailService,
	smsSvc helpers.SMSService,
	rateLimiter *middleware.RateLimiter,
	log *slog.Logger,
) *AuthService {
	return &AuthService{
		userRepo:    userRepo,
		sessionRepo: sessionRepo,
		otpRepo:     otpRepo,
		jwtManager:  jwtManager,
		emailSvc:    emailSvc,
		smsSvc:      smsSvc,
		rateLimiter: rateLimiter,
		log:         log,
	}
}

// Login runs the full documented flow and returns one of three response
// types depending on the account's state — normal login, first-time
// login (onboarding required), or MFA required. All three are 200s;
// the controller marshals whichever concrete type comes back as-is via
// helpers.SuccessResponse, so it doesn't need to switch on the type
// itself. Any error returned is either an *helpers.AppError (safe to
// show the client) or an unexpected error for the controller to log and
// mask behind a generic 500.
func (s *AuthService) Login(ctx context.Context, req models.LoginRequest, clientIP string) (any, error) {
	rateLimitKey := req.Identifier + "|" + clientIP

	// Rate limit check happens BEFORE the DB lookup.
	if blocked, retryAfter := s.rateLimiter.IsBlocked(rateLimitKey); blocked {
		return nil, helpers.ErrRateLimited(retryAfter)
	}

	// Step 1 & 2: detect identifier type, look up the user.
	var user *models.User
	var err error
	if helpers.IsEmailIdentifier(req.Identifier) {
		user, err = s.userRepo.FindByEmail(ctx, req.Identifier)
	} else {
		user, err = s.userRepo.FindByMobile(ctx, req.Identifier)
	}
	if err != nil {
		if errors.Is(err, helpers.ErrNotFound) {
			// Step 3: never reveal that the identifier doesn't exist —
			// same message and same rate-limit accounting as a wrong
			// password, so the two cases are indistinguishable to a caller.
			s.rateLimiter.RecordFailure(rateLimitKey)
			return nil, helpers.ErrInvalidCredentials()
		}
		return nil, fmt.Errorf("services: find user: %w", err)
	}

	// Step 4: verify password. Same generic error as Step 3.
	if !helpers.ComparePassword(req.Password, user.PasswordHash) {
		s.rateLimiter.RecordFailure(rateLimitKey)
		return nil, helpers.ErrInvalidCredentials()
	}

	// A correct password is a success for rate-limiting purposes, even
	// if the response below branches into onboarding or MFA.
	s.rateLimiter.Reset(rateLimitKey)

	// Step 6: first-time login — send to onboarding, no full session.
	if user.IsFirstLogin {
		tempToken, err := s.jwtManager.GenerateTempToken(user.ID)
		if err != nil {
			return nil, fmt.Errorf("services: generate temp token: %w", err)
		}
		return &models.LoginFirstTimeResponse{
			RequiresOnboarding: true,
			TempToken:          tempToken,
		}, nil
	}

	// Step 7: MFA — issue an OTP instead of a full session.
	if user.MFAEnabled {
		return s.triggerMFA(ctx, user)
	}

	// Step 8 & 9: normal login — issue access + refresh tokens.
	return s.issueSession(ctx, user)
}

// triggerMFA generates and stores a 6-digit OTP, delivers it via the
// user's configured channel, and returns the mfa_pending_token. The
// user is NOT logged in at this point.
func (s *AuthService) triggerMFA(ctx context.Context, user *models.User) (*models.LoginMFARequiredResponse, error) {
	otp, err := helpers.GenerateOTP()
	if err != nil {
		return nil, fmt.Errorf("services: generate otp: %w", err)
	}

	otpRecord := &models.MFAOtp{
		UserID:    user.ID,
		OTPHash:   helpers.HashOTP(otp),
		ExpiresAt: time.Now().Add(mfaOTPTTL),
	}
	if err := s.otpRepo.Create(ctx, otpRecord); err != nil {
		return nil, fmt.Errorf("services: store otp: %w", err)
	}

	if err := s.deliverOTP(user, otp); err != nil {
		// Delivery failing shouldn't surface the underlying provider
		// error to the client — but it IS an important event to log,
		// since a user is now stuck unable to receive their OTP.
		s.log.Error("mfa otp delivery failed", "user_id", user.ID, "error", err)
		return nil, fmt.Errorf("services: deliver otp: %w", err)
	}

	mfaPendingToken, err := s.jwtManager.GenerateMFAPendingToken(user.ID)
	if err != nil {
		return nil, fmt.Errorf("services: generate mfa pending token: %w", err)
	}

	return &models.LoginMFARequiredResponse{
		MFARequired:     true,
		MFAPendingToken: mfaPendingToken,
	}, nil
}

func (s *AuthService) deliverOTP(user *models.User, otp string) error {
	method := "email"
	if user.MFAMethod != nil {
		method = *user.MFAMethod
	}

	switch method {
	case "sms":
		if user.Mobile == nil {
			return fmt.Errorf("mfa_method is sms but user has no mobile number on file")
		}
		return s.smsSvc.SendOTP(*user.Mobile, otp)
	default: // "email"
		return s.emailSvc.SendOTP(user.Email, otp)
	}
}

// issueSession signs a full access token and issues a rotated refresh
// token — the normal-login success path (Steps 8-9).
func (s *AuthService) issueSession(ctx context.Context, user *models.User) (*models.LoginSuccessResponse, error) {
	accessToken, err := s.jwtManager.GenerateAccessToken(user.ID, user.Role, user.Email)
	if err != nil {
		return nil, fmt.Errorf("services: generate access token: %w", err)
	}

	rawRefreshToken, err := helpers.GenerateRefreshToken()
	if err != nil {
		return nil, fmt.Errorf("services: generate refresh token: %w", err)
	}

	refreshRecord := &models.RefreshToken{
		UserID:    user.ID,
		TokenHash: helpers.HashRefreshToken(rawRefreshToken),
		ExpiresAt: time.Now().Add(refreshTokenTTL),
	}
	if err := s.sessionRepo.Create(ctx, refreshRecord); err != nil {
		return nil, fmt.Errorf("services: store refresh token: %w", err)
	}

	return &models.LoginSuccessResponse{
		AccessToken:  accessToken,
		RefreshToken: rawRefreshToken,
		User: models.UserSummary{
			ID:             user.ID,
			Email:          user.Email,
			Mobile:         user.Mobile,
			Role:           user.Role,
			EmailVerified:  user.EmailVerified,
			MobileVerified: user.MobileVerified,
		},
	}, nil
}

// Refresh exchanges a valid refresh token for a new access + refresh
// pair, revoking the old one FIRST per the doc's explicit security
// rule — a crash between revoke and issue must never leave two
// simultaneously-valid refresh tokens.
func (s *AuthService) Refresh(ctx context.Context, req models.RefreshRequest) (*models.RefreshResponse, error) {
	tokenHash := helpers.HashRefreshToken(req.RefreshToken)

	tokenRecord, err := s.sessionRepo.FindActiveByHash(ctx, tokenHash)
	if err != nil {
		if errors.Is(err, helpers.ErrNotFound) {
			return nil, helpers.ErrTokenInvalid("Invalid or expired token")
		}
		return nil, fmt.Errorf("services: find refresh token: %w", err)
	}

	// Revoke first, then issue — see the doc's "Security Rule: Revoke
	// first, then issue" callout.
	if err := s.sessionRepo.Revoke(ctx, tokenRecord.ID); err != nil {
		return nil, fmt.Errorf("services: revoke refresh token: %w", err)
	}

	user, err := s.userRepo.FindByID(ctx, tokenRecord.UserID)
	if err != nil {
		if errors.Is(err, helpers.ErrNotFound) {
			// Token was valid but its owning user is gone — treat as an
			// invalid session rather than a 500.
			return nil, helpers.ErrTokenInvalid("Invalid or expired token")
		}
		return nil, fmt.Errorf("services: find user for refresh: %w", err)
	}

	newAccessToken, err := s.jwtManager.GenerateAccessToken(user.ID, user.Role, user.Email)
	if err != nil {
		return nil, fmt.Errorf("services: generate access token: %w", err)
	}

	newRawRefreshToken, err := helpers.GenerateRefreshToken()
	if err != nil {
		return nil, fmt.Errorf("services: generate refresh token: %w", err)
	}

	newRecord := &models.RefreshToken{
		UserID:    user.ID,
		TokenHash: helpers.HashRefreshToken(newRawRefreshToken),
		ExpiresAt: time.Now().Add(refreshTokenTTL),
	}
	if err := s.sessionRepo.Create(ctx, newRecord); err != nil {
		return nil, fmt.Errorf("services: store rotated refresh token: %w", err)
	}

	return &models.RefreshResponse{
		AccessToken:  newAccessToken,
		RefreshToken: newRawRefreshToken,
	}, nil
}